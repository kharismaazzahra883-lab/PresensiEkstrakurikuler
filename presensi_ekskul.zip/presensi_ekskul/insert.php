<?php

include 'koneksi.php';

$nis = isset($_POST['nis']) ? $_POST['nis'] : '';
$nama = isset($_POST['nama']) ? $_POST['nama'] : '';

if ($nis != '' && $nama != '') {

    $query = "INSERT INTO tb_presensi (nis, nama)
              VALUES ('$nis', '$nama')";

    if (mysqli_query($koneksi, $query)) {

        echo "Presensi berhasil disimpan";

    } else {

        echo "Gagal menyimpan: " . mysqli_error($koneksi);

    }

} else {

    echo "Data NIS dan nama belum lengkap";

}

?>