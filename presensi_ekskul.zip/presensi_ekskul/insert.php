<?php

include 'koneksi.php';

$nis = isset($_POST['nis']) ? trim($_POST['nis']) : '';
$nama = isset($_POST['nama']) ? trim($_POST['nama']) : '';
$ekstrakurikuler = isset($_POST['ekstrakurikuler']) ? trim($_POST['ekstrakurikuler']) : '';

if ($nis == '' || $nama == '' || $ekstrakurikuler == '') {

    echo "Data NIS, nama, dan ekstrakurikuler wajib diisi";
    exit;
}

$query = "INSERT INTO tb_presensi (nis, nama, ekstrakurikuler)
          VALUES (?, ?, ?)";

$stmt = mysqli_prepare($koneksi, $query);

mysqli_stmt_bind_param(
    $stmt,
    "sss",
    $nis,
    $nama,
    $ekstrakurikuler
);

if (mysqli_stmt_execute($stmt)) {

    echo "Presensi berhasil disimpan";

} else {

    echo "Gagal menyimpan: " . mysqli_error($koneksi);
}

mysqli_stmt_close($stmt);

?>