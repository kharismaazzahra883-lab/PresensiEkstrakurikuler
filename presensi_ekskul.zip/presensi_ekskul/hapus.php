<?php

include 'koneksi.php';

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $query = "DELETE FROM tb_presensi WHERE id = '$id'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($koneksi);
    }

} else {

    echo "ID data tidak ditemukan";

}

?>