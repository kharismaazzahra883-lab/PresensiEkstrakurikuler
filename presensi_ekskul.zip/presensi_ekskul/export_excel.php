<?php

include 'koneksi.php';

$tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';

$ekstrakurikuler = isset($_GET['ekstrakurikuler'])
    ? $_GET['ekstrakurikuler']
    : '';

$query = "SELECT * FROM tb_presensi WHERE 1=1";

if ($tanggal != '') {

    $tanggal = mysqli_real_escape_string($koneksi, $tanggal);

    $query .= " AND DATE(waktu) = '$tanggal'";
}

if ($ekstrakurikuler != '') {

    $ekstrakurikuler = mysqli_real_escape_string(
        $koneksi,
        $ekstrakurikuler
    );

    $query .= " AND ekstrakurikuler = '$ekstrakurikuler'";
}

$query .= " ORDER BY waktu DESC";

$result = mysqli_query($koneksi, $query);

header("Content-Type: application/vnd.ms-excel");

header(
    "Content-Disposition: attachment; filename=Rekap_Presensi_Ekstrakurikuler.xls"
);

?>

<html>

<head>

    <meta charset="UTF-8">

</head>

<body>

<h2>Rekap Presensi Ekstrakurikuler</h2>

<?php if ($tanggal != '') { ?>

<p>
    Tanggal: <?php echo htmlspecialchars($tanggal); ?>
</p>

<?php } ?>

<?php if ($ekstrakurikuler != '') { ?>

<p>
    Ekstrakurikuler:
    <?php echo htmlspecialchars($ekstrakurikuler); ?>
</p>

<?php } ?>

<table border="1">

    <tr>

        <th>No</th>

        <th>Waktu Presensi</th>

        <th>NIS</th>

        <th>Nama Siswa</th>

        <th>Ekstrakurikuler</th>

    </tr>

    <?php

    $no = 1;

    while ($data = mysqli_fetch_assoc($result)) {

    ?>

    <tr>

        <td>
            <?php echo $no++; ?>
        </td>

        <td>
            <?php echo $data['waktu']; ?>
        </td>

        <td>
            <?php echo $data['nis']; ?>
        </td>

        <td>
            <?php echo $data['nama']; ?>
        </td>

        <td>
            <?php echo $data['ekstrakurikuler']; ?>
        </td>

    </tr>

    <?php } ?>

</table>

</body>

</html>