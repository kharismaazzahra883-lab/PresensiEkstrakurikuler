<?php

include 'koneksi.php';

$tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';

if ($tanggal != '') {

    $query = "SELECT * FROM tb_presensi
              WHERE DATE(waktu) = '$tanggal'
              ORDER BY waktu DESC";

} else {

    $query = "SELECT * FROM tb_presensi
              ORDER BY waktu DESC";
}

$result = mysqli_query($koneksi, $query);

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Rekap_Presensi_Ekstrakurikuler.xls");

?>

<html>
<head>
    <meta charset="UTF-8">
</head>

<body>

<h2>Rekap Presensi Ekstrakurikuler</h2>

<?php if ($tanggal != '') { ?>
    <p>Tanggal: <?php echo $tanggal; ?></p>
<?php } ?>

<table border="1">

    <tr>
        <th>No</th>
        <th>Waktu Presensi</th>
        <th>NIS</th>
        <th>Nama Siswa</th>
    </tr>

    <?php

    $no = 1;

    while ($data = mysqli_fetch_assoc($result)) {

    ?>

    <tr>

        <td><?php echo $no++; ?></td>

        <td><?php echo $data['waktu']; ?></td>

        <td><?php echo $data['nis']; ?></td>

        <td><?php echo $data['nama']; ?></td>

    </tr>

    <?php } ?>

</table>

</body>
</html>