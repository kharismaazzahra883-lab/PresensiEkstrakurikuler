<?php
include 'koneksi.php';

$tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$ekstrakurikuler = isset($_GET['ekstrakurikuler']) ? $_GET['ekstrakurikuler'] : '';

$query = "SELECT * FROM tb_presensi WHERE 1=1";

if ($tanggal != '') {
    $query .= " AND DATE(waktu) = '" . mysqli_real_escape_string($koneksi, $tanggal) . "'";
}

if ($ekstrakurikuler != '') {
    $query .= " AND ekstrakurikuler = '" . mysqli_real_escape_string($koneksi, $ekstrakurikuler) . "'";
}

$query .= " ORDER BY waktu DESC";

$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Rekap Presensi Ekstrakurikuler</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f7f6;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.15);
        }

        h1 {
            text-align: center;
            margin-bottom: 25px;
        }

        .filter {
            text-align: center;
            margin-bottom: 20px;
        }

        input[type="date"],
        select {
            padding: 8px;
            font-size: 15px;
            margin: 5px;
        }

        button {
            padding: 9px 18px;
            border: none;
            color: white;
            cursor: pointer;
            font-size: 15px;
            margin: 5px;
            border-radius: 4px;
        }

        .btn-filter {
            background: #28a745;
        }

        .btn-reset {
            background: #dc3545;
        }

        .btn-excel {
            background: #17a2b8;
        }

        .btn-pdf {
            background: #6f42c1;
        }

        .btn-hapus {
            background: #dc3545;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #087ff5;
            color: white;
            padding: 12px;
        }

        td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background: #f2f2f2;
        }

        @media print {

            body {
                background: white;
                padding: 0;
            }

            .container {
                box-shadow: none;
                max-width: 100%;
            }

            .filter {
                display: none;
            }

            h1 {
                margin-top: 20px;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <h1>Rekap Presensi Ekstrakurikuler</h1>

    <div class="filter">

        <form method="GET">

            <label>
                <b>Pilih Tanggal:</b>
            </label>

            <input
                type="date"
                name="tanggal"
                value="<?php echo htmlspecialchars($tanggal); ?>"
            >

            <label>
                <b>Pilih Ekstrakurikuler:</b>
            </label>

            <select name="ekstrakurikuler">

                <option value="">Semua Ekstrakurikuler</option>

                <option value="Pramuka"
                    <?php if ($ekstrakurikuler == 'Pramuka') echo 'selected'; ?>>
                    Pramuka
                </option>

                <option value="PMR"
                    <?php if ($ekstrakurikuler == 'PMR') echo 'selected'; ?>>
                    PMR
                </option>

                <option value="Paskibra"
                    <?php if ($ekstrakurikuler == 'Paskibra') echo 'selected'; ?>>
                    Paskibra
                </option>

                <option value="Futsal"
                    <?php if ($ekstrakurikuler == 'Futsal') echo 'selected'; ?>>
                    Futsal
                </option>

                <option value="Voli"
                    <?php if ($ekstrakurikuler == 'Voli') echo 'selected'; ?>>
                    Voli
                </option>

            </select>

            <button type="submit" class="btn-filter">
                Filter
            </button>

            <button
                type="button"
                class="btn-reset"
                onclick="window.location.href='index.php'"
            >
                Reset
            </button>

            <button
                type="button"
                class="btn-excel"
                onclick="exportExcel()"
            >
                Cetak Excel
            </button>

            <button
                type="button"
                class="btn-pdf"
                onclick="window.print()"
            >
                Export PDF
            </button>

        </form>

    </div>

    <table>

        <tr>
            <th>No</th>
            <th>Waktu Presensi</th>
            <th>NIS</th>
            <th>Nama Siswa</th>
            <th>Ekstrakurikuler</th>
            <th>Action</th>
        </tr>

        <?php

        $no = 1;

        if (mysqli_num_rows($result) > 0) {

            while ($data = mysqli_fetch_assoc($result)) {

        ?>

        <tr>

            <td>
                <?php echo $no++; ?>
            </td>

            <td>
                <?php echo $data['waktu']; ?>
            </td>

            <td>
                <?php echo htmlspecialchars($data['nis']); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($data['nama']); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($data['ekstrakurikuler']); ?>
            </td>

            <td>

                <a
                    href="hapus.php?id=<?php echo $data['id']; ?>"
                    onclick="return confirm('Yakin ingin menghapus data ini?')"
                    class="btn-hapus"
                >
                    Hapus
                </a>

            </td>

        </tr>

        <?php

            }

        } else {

        ?>

        <tr>

            <td colspan="6">
                Belum ada data presensi
            </td>

        </tr>

        <?php

        }

        ?>

    </table>

</div>

<script>

function exportExcel() {

    var tanggal =
        document.querySelector('input[name="tanggal"]').value;

    var ekstrakurikuler =
        document.querySelector('select[name="ekstrakurikuler"]').value;

    var url = 'export_excel.php?';

    if (tanggal != '') {
        url += 'tanggal=' + encodeURIComponent(tanggal);
    }

    if (ekstrakurikuler != '') {

        if (tanggal != '') {
            url += '&';
        }

        url += 'ekstrakurikuler=' +
               encodeURIComponent(ekstrakurikuler);
    }

    window.location.href = url;

}

</script>

</body>

</html>